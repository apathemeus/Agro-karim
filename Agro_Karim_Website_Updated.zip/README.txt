AGRO KARIM — TRILINGUAL PRODUCT CATALOGUE

Files:
- index.html: the website. Open this file in a browser to preview it.

Features:
- English, French and Arabic language switcher (Arabic uses RTL layout)
- Product catalogue, category filters and search
- Sample product cards with blank prices (replace with your real products/prices)
- WhatsApp/email contact links (configure in the source or use browser storage)
- Local product manager: click "Gérer les produits" in the footer to add/edit/delete products
- JSON import/export for backing up the catalogue

IMPORTANT LIMITATIONS:
- This is a static prototype. Product changes are stored only in the current browser's local storage.
- They do not automatically appear on other devices or update a deployed copy of the website.
- WhatsApp is preconfigured to +213 658 33 81 26 (converted from the supplied Algerian number 0658338126). The email button is hidden until an email address is configured.
- Product images use remote Unsplash image URLs and therefore need an internet connection.
- The sample products are examples, not a verified statement of current stock or pricing.
- To publish publicly for free, upload index.html to a static host such as GitHub Pages or Cloudflare Pages. You will need to create/configure the hosting account yourself. A custom domain usually costs extra.

PRODUCT EDITING:
Click "Gérer les produits" in the page footer. You can add, edit, and delete products and export/import the catalogue as a JSON backup. Product edits are saved in that browser only. They are not shared between devices and do not update the online website automatically.
